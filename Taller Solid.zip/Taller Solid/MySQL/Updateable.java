package MySQL;

public interface Updateable {
    public void update(String statement);;
}
