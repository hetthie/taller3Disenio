package MySQL;

public interface Selectable {
  public void select(String statement);;
}
