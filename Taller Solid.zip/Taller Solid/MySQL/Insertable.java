package MySQL;

public interface Insertable {
    public void insert(String statement);;
}
