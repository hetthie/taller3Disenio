package MySQL;

public interface Deletable {
    public void delete(String statement);;
}
