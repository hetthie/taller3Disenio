public class CloudServicePlatform {
    private int cloudServicePlatform;
    private String name;

    public CloudServicePlatform(int code, String name){
        this.cloudServicePlatform = code;
        this.name = name;
    }

    //Open-Closed Principle
    /* Si se desea agregar otro servicio en la nube se deberá modificar el método hostingTo rompiendo
    el Principio de Abierto-Cerrado. */

    public void hostingTo (AppWeb app) {
        System.out.println("Connect to" + name);
        //logic
    }
    // More Methods
}

