public class LogIn{

    public void log (User user) {
        System.out.println("Has access to the website");
        insertUserInDatabase(user);
        // Logic
    }

    //Single Responsibility Principle
    /* El método insertUserInDatabase debería estar en otra clase para hacer la verificación.
    No es responsabilidad de la clase LogIn */

    //Integration Segregation Principle
    /* El método insertUserInDatabase no será usado por todas las instancias de LogIn y debería ser
    responsabilidad de una Interfaz para segregar mejor sus interacciones con la base de Datos y los SQL*/

    public void insertUserInDatabase(User user){
        // Insert user in database
    }

}

