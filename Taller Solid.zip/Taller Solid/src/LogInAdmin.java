public class LogInAdmin extends LogIn {

    @Override
    public void log (User user) {
        if(!user.isAdmin()){
            return;
        }
        System.out.println("Has access to the website in admin mode");
        // Logic
    }

    //Liskov Substitution Principle
    /* Se rompé el Principio de Sustitución de Liskov al intentar utilizar el método verifyIfTheUserIsAdmin 
    o querer acceder al atributo userIsAdmin desde un objeto de clase LogIn ya que este último no posee dichas facultades */

}

